"use client";

import { useState, useEffect } from "react";
import { useTranslations } from "next-intl";
import { usePathname, useRouter } from "next/navigation";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";

const LOCALES = [
  { code: "es", label: "ES", flag: "🇪🇸" },
  { code: "en", label: "EN", flag: "🇺🇸" },
  { code: "de", label: "DE", flag: "🇩🇪" },
];

export default function Navbar() {
  const t = useTranslations("nav");
  const pathname = usePathname();
  const router = useRouter();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Detect current locale from pathname
  const currentLocale =
    LOCALES.find((l) => pathname.startsWith(`/${l.code}`))?.code ?? "es";

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const switchLocale = (locale: string) => {
    const segments = pathname.split("/").filter(Boolean);
    const hasLocale = LOCALES.some((l) => l.code === segments[0]);
    const rest = hasLocale ? segments.slice(1) : segments;
    const newPath = locale === "es" ? `/${rest.join("/")}` : `/${locale}/${rest.join("/")}`;
    router.push(newPath);
  };

  const navLinks = [
    { href: "#services", label: t("services") },
    { href: "#about", label: t("about") },
    { href: "#suite", label: t("suite") },
    { href: "#contact", label: t("contact") },
  ];

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "py-3 bg-brand-void/90 backdrop-blur-xl border-b border-gold-400/10 shadow-gold-sm"
          : "py-5 bg-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <a href="/" className="flex items-center gap-3 group">
          <div className="relative w-8 h-8">
            {/* S87 Logo Mark */}
            <div className="w-8 h-8 rounded-lg bg-gold-gradient flex items-center justify-center shadow-gold-sm group-hover:shadow-gold-md transition-shadow">
              <span className="text-brand-black font-display font-bold text-xs tracking-tight">
                S87
              </span>
            </div>
            <div className="absolute inset-0 rounded-lg bg-gold-gradient opacity-0 group-hover:opacity-20 blur-md transition-opacity" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="font-display font-bold text-text-primary text-base tracking-tight">
              Summer87
            </span>
            <span className="font-mono text-[10px] text-gold-400 tracking-widest uppercase opacity-70">
              Intelligence
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm text-text-secondary hover:text-text-primary transition-colors duration-200 font-medium relative group"
            >
              {link.label}
              <span className="absolute -bottom-1 left-0 w-0 h-px bg-gold-400 group-hover:w-full transition-all duration-300" />
            </a>
          ))}
        </nav>

        {/* Right side */}
        <div className="hidden md:flex items-center gap-4">
          {/* Language switcher */}
          <div className="flex items-center gap-1 p-1 rounded-lg bg-brand-surface border border-brand-border">
            {LOCALES.map((locale) => (
              <button
                key={locale.code}
                onClick={() => switchLocale(locale.code)}
                className={cn(
                  "px-2 py-1 rounded text-xs font-mono font-medium transition-all duration-200",
                  currentLocale === locale.code
                    ? "bg-gold-400 text-brand-black"
                    : "text-text-muted hover:text-text-secondary"
                )}
              >
                {locale.label}
              </button>
            ))}
          </div>

          {/* CTA */}
          <a href="#contact" className="btn-gold text-xs px-5 py-2.5">
            <span>{t("cta")}</span>
          </a>
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-text-secondary hover:text-gold-400 transition-colors"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      <div
        className={cn(
          "md:hidden transition-all duration-300 overflow-hidden",
          mobileOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
        )}
      >
        <div className="px-6 py-4 bg-brand-void/95 backdrop-blur-xl border-t border-brand-border space-y-4">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className="block text-sm text-text-secondary hover:text-gold-400 transition-colors py-2 font-medium"
            >
              {link.label}
            </a>
          ))}
          <div className="pt-2 flex items-center gap-2">
            {LOCALES.map((locale) => (
              <button
                key={locale.code}
                onClick={() => {
                  switchLocale(locale.code);
                  setMobileOpen(false);
                }}
                className={cn(
                  "px-3 py-1.5 rounded text-xs font-mono font-semibold transition-all",
                  currentLocale === locale.code
                    ? "bg-gold-400 text-brand-black"
                    : "border border-brand-border text-text-muted hover:text-text-secondary"
                )}
              >
                {locale.flag} {locale.label}
              </button>
            ))}
          </div>
          <a
            href="#contact"
            onClick={() => setMobileOpen(false)}
            className="btn-gold w-full text-center text-sm mt-2 block"
          >
            <span>{t("cta")}</span>
          </a>
        </div>
      </div>
    </header>
  );
}
