import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Summer87 Design System — Corporate IA Disruptiva
        brand: {
          black:   "#08080D",
          void:    "#0C0C14",
          deep:    "#10101A",
          surface: "#16161F",
          card:    "#1C1C28",
          border:  "#252535",
          muted:   "#2E2E42",
        },
        gold: {
          50:  "#FDF8EC",
          100: "#F9EEC9",
          200: "#F2D98A",
          300: "#E8C14A",
          400: "#D4AF37",   // Primary Gold
          500: "#C09A28",
          600: "#A07D1C",
          700: "#7A5E13",
          800: "#54400C",
          900: "#2E2205",
        },
        amber: {
          glow: "#F59E0B",
          soft: "#FCD34D",
        },
        text: {
          primary:   "#F0EEF8",
          secondary: "#A09BB8",
          muted:     "#5C576E",
          inverse:   "#08080D",
        },
      },
      fontFamily: {
        sans:    ["Inter", "system-ui", "sans-serif"],
        display: ["Syne", "Inter", "system-ui", "sans-serif"],
        mono:    ["JetBrains Mono", "monospace"],
      },
      backgroundImage: {
        "gradient-radial":   "radial-gradient(var(--tw-gradient-stops))",
        "gradient-conic":    "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
        "gold-gradient":     "linear-gradient(135deg, #D4AF37 0%, #F59E0B 50%, #C09A28 100%)",
        "dark-gradient":     "linear-gradient(180deg, #08080D 0%, #10101A 100%)",
        "hero-mesh":         "radial-gradient(ellipse 80% 50% at 50% -20%, rgba(212,175,55,0.15), transparent)",
        "card-shine":        "linear-gradient(135deg, rgba(212,175,55,0.08) 0%, transparent 60%)",
      },
      boxShadow: {
        "gold-sm":  "0 0 15px rgba(212,175,55,0.15)",
        "gold-md":  "0 0 30px rgba(212,175,55,0.20)",
        "gold-lg":  "0 0 60px rgba(212,175,55,0.25)",
        "gold-xl":  "0 0 100px rgba(212,175,55,0.30)",
        "inner-gold": "inset 0 1px 0 rgba(212,175,55,0.15)",
        "card":     "0 4px 24px rgba(0,0,0,0.40), 0 1px 0 rgba(212,175,55,0.08)",
      },
      animation: {
        "fade-up":       "fadeUp 0.6s ease-out forwards",
        "fade-in":       "fadeIn 0.4s ease-out forwards",
        "glow-pulse":    "glowPulse 3s ease-in-out infinite",
        "float":         "float 6s ease-in-out infinite",
        "scan-line":     "scanLine 8s linear infinite",
        "data-stream":   "dataStream 4s linear infinite",
      },
      keyframes: {
        fadeUp: {
          "0%":   { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        fadeIn: {
          "0%":   { opacity: "0" },
          "100%": { opacity: "1" },
        },
        glowPulse: {
          "0%, 100%": { boxShadow: "0 0 20px rgba(212,175,55,0.20)" },
          "50%":      { boxShadow: "0 0 40px rgba(212,175,55,0.40)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%":      { transform: "translateY(-12px)" },
        },
        scanLine: {
          "0%":   { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100vh)" },
        },
        dataStream: {
          "0%":   { opacity: "0", transform: "translateY(-10px)" },
          "50%":  { opacity: "1" },
          "100%": { opacity: "0", transform: "translateY(10px)" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
